<?php 
echo '<u>Jugador 1</u></b><br><br>';
$n1=0;
$n2=0;
for ($i=0; $i < 5; $i++) { 
    $d=mt_rand(1,6);
    $n1+=$d;
    print "<img src=img/$d.jpg>";
}echo "<br><br>";
echo '<b><u>Jugador 2</u></b><br><br>';
for ($i=0; $i < 5; $i++) { 
    $d=mt_rand(1,6);
    $n2+=$d;
    print "<img src=img/$d.jpg>";

}
echo "<br><br>";   
echo '<b><u>Resultado</u></b><br><br>';



    ?>
<html>
    <label style="font-size: 10%;"></label>
    <table>
    <td><?php 
    if ($n1>$n2) {
            echo "<p>El ganador es el jugador 1 con $n1 puntos<p>";
    }elseif ($n2>$n1) {
        echo "<p>El ganador es el jugador 2 con $n2 puntos<p>";
    }
    else {
        echo "<p>¡EMPATE!</p>";
    }
    ?></td><p></p>
</table>
</html>