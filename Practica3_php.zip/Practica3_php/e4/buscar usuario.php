<?php
    $nombre=$_REQUEST['nombre2'];

if(isset($_REQUEST['buscarc'])){ 
    $fp=fopen("usuarios.txt", "r");

    while (!feof($fp)) {
        $linea =fgets($fp);
        if (strpos($linea, $nombre)) {
            echo "$linea\n";
}
}
}        fclose($fp);


?>