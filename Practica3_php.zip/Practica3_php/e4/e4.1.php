<?php 
    $siguiente=$_REQUEST['siguiente'];
    $user=$_REQUEST['user'];
    $nombre=$_REQUEST['nombre2'];

    if(isset($_REQUEST['siguiente'])){ 
        if ($user=='uno') {

            echo '        <form action="buscar usuario.php" method="post">
            <label>Nombre:</label>        <input type="text" name="nombre2"><br>           
            <input type="submit" id="buscar"  value="buscar contacto" name="buscarc"></form>
';

        
        }
       
    
    else{
        $fd=fopen("usuarios.txt", "r");

        while (!feof($fd)) {  
            $linea=fgets($fd);
            echo $linea."<br>";
        }
        fclose($fd);
    }
}

?>