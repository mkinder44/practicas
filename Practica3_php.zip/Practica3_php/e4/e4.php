<?php 
    if (isset($_REQUEST['guardar'])){       
        $nombre=$_REQUEST['nombre'];
        $trabajo=$_REQUEST['trabajo'];
        $telefono=$_REQUEST['telefono'];
        $direccion=$_REQUEST['direccion'];
        $otras=$_REQUEST['otras'];
        $user=$_REQUEST['user'];
        
    
    if ($nombre == null || $trabajo == null || $telefono==null || $direccion==null) {
        echo "Debes completar todos los campos<br>";
    }else if(isset($_REQUEST['guardar'])){
        $fp=fopen('usuarios.txt','a');
        if ($otras==null) {
            fputs($fp, "Contacto: $nombre , $trabajo, $telefono, $direccion");
            fputs($fp, "\n");
        }else{
                    fputs($fp, "Contacto: $nombre, $trabajo, $telefono, $direccion, $otras\n");

        }
        fclose($fp);
    
        print '
        <form action="e4.1.php" method="post">
        <input type="radio" id="uno"  value="uno" name="user"><label>Busca a un usuario<label></label><br>
         <input type="radio" id="todos"  value="todos" name="user"><label>mostrar todos los contactos<label></label><br>
        <input type="submit" id="siguiente"  value="siguiente" name="siguiente">


    </form>   
        ';
    }
}
    else{
    ?>
    <html>
    <head>
        <style type="text/css">
            p{
                font-size: 1.5em;
            }
            label{
                font-size: 1.2em;

            }
            h1{
                font-size: 2.5em;
                margin-bottom: 0.5%;
            }
            input{
                font-size: 1.2em;
            }
        </style>
        </head>
        <body>
            <p>Agenda Virtual PHP</p>
            <h1><b>Contactos</b></h1>
            <form action="e4.php" method="post">
                <label>Para guardar presione el botón<label></label><br>
                <label>Nombre:</label>        <input type="text" name="nombre"><br>
                <label>Trabajo:</label>       <input type="text" name="trabajo"><br>
                <label>Telefono:</label>      <input type="tel" name="telefono"><br>
                <label>Direccion:</label>     <input type="text" name="direccion"><br>
                <label>Otras:</label>         <input type="text" name="otras"><br>
                <input type="submit" id="guardar"  value="Guardar" name="guardar">
                <input type="reset" id="borrar"  value="Borrar">


            </form>    
        </body>
    
    </html>
<?php 
}
?>