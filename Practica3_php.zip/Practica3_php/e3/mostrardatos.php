<?php 
    $nombre = $_REQUEST['nombre'];
    $telefono = $_REQUEST['telefono'];
    $enseñanza = $_REQUEST['enseñanza'];
    $mostrar=$_REQUEST['mostrar'];
    $matriculado=$_REQUEST['matriculado'];  


    $fp=fopen('datos.txt', 'r');
    while (!feof($fp)) {  
        $linea=fgets($fp);
        echo $linea."<br>";
    }
    fclose($fp);
?>