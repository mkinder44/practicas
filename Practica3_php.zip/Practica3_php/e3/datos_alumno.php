<?php 
$nombre = $_REQUEST['nombre'];
$telefono = $_REQUEST['telefono'];
$enseñanza = $_REQUEST['enseñanza'];
$mostrar=$_REQUEST['mostrar'];
$matriculado=$_REQUEST['matriculado'];
if ($nombre == null || $telefono == null || $enseñanza== null) {
    echo "completa todos los campos";    
}else if($mostrar=='pantalla'){
    if ($matriculado==true) {
    
    echo "El alumno $nombre, con telefono $telefono, está matriculado en $enseñanza";
    }elseif ($matriculado==false) {
        echo "El alumno $nombre, con telefono $telefono, no está  matriculado actualmente en $enseñanza";
    }
}


?>