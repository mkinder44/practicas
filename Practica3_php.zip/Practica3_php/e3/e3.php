<?php
if (isset($_REQUEST['enviar'])) {

    $nombre = $_REQUEST['nombre'];
    $telefono = $_REQUEST['telefono'];
    $enseñanza = $_REQUEST['enseñanza'];
    $mostrar=$_REQUEST['mostrar'];
    $matriculado=$_REQUEST['matriculado'];

    if ($mostrar=='archivo') {
        $fp=fopen("datos.txt", "a");
        if ($matriculado==true) {
        fputs($fp, "El alumno $nombre, con telefono $telefono, está matriculado en $enseñanza\n");
        }elseif ($matriculado==false) {
            fputs($fp, "El alumno $nombre, con telefono $telefono, no está  matriculado actualmente en $enseñanza\n");
        }
        fclose($fp);
        if ($mostrar=='archivo') {
            echo "<a href='mostrardatos.php'>mostrar archivo</a>";
        }

    }else if($mostrar=='pantalla'){
        if ($matriculado==true) {
        
        echo "El alumno $nombre, con telefono $telefono, está matriculado en $enseñanza";
        }elseif ($matriculado==false) {
            echo "El alumno $nombre, con telefono $telefono, no está  matriculado actualmente en $enseñanza";
        }
    }

} else {
?>
    <html><head>
        
        </head><body>
       <div id="cuadro">
           <label id="datos">DATOS DEL ALUMNO: </label><br>
            <form action="e3.php" method="post">
            <div id="div2">
                <label id="ens">Enseñanza: </label><br>
                    <input type="radio"  value="secundaria" class="radio" name="enseñanza"><label>Secundaria</label>&nbsp&nbsp
                    <input type="radio" value="bachillerato" class="radio" name="enseñanza"><label>Bachillerato</label><br>
                    <input type="radio" value="Ciclo medio" class="radio" name="enseñanza"><label>Ciclo Medio</label>
                    <input type="radio" value="Ciclo " class="radio" name="enseñanza" ><label>Ciclo Superior</label>
            </div>
            <div id="div1">
                <label> Introduzca su <br> nombre: </label><br>
                <input type="text" class="text" name="nombre"><br>
                <label>Introduzca su <br> telefono:</label><br>
                <input type="tel" class="text" name="telefono" size="10">
                
                <label>Matriculado</label><input type="checkbox" value="mat" name="matriculado"><br>
                
                <lablel>Mostrar datos</lablel>

                <select name="mostrar" id="mostrar">
                    <option value="pantalla">Por Pantalla</option>
                    <option value="archivo">En Archivo datos.txt</option>
                </select>
            </div>
       </div>
               <input type="submit" value="Enviar datos" name="enviar"><label></label>
       </form>
    </body>

    </html>
<?php
}
?>

