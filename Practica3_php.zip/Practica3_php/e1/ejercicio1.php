<?php
if (isset($_REQUEST['dibujar'])) {

    $ancho = $_REQUEST['ancho'];
    $alto = $_REQUEST['alto'];
    $caracter = $_REQUEST['caracter'];
    




    if ($ancho == null || $alto == null || $caracter== null || $caracter==' ') {
        echo "completa todos los campos";
    } elseif ($ancho<=0 || $ancho>100|| $alto<0 || $alto>100) {
        echo "el ancho y el alto tiene que estar entre 0 y 100";
    }
    else {
        echo "Ancho: $ancho <br> Alto: $alto<br>";
        for ($i=0; $i < $alto; $i++) { 
            for ($f=0; $f < $ancho; $f++) { 
                echo "<b>­­­­$_REQUEST[caracter]&nbsp&nbsp&nbsp</b>";
                
            }
           echo "<br>";
        }
        

    }
} else {
?>
    <html>

    <head>
       
    </head>

    <body>
        <fieldset>
            <legend>Formulario</legend><br>
            <p>Escriba el alto, el ancho (0 < números ≤ 100) y el caractér que prefieras y mostraré un rectángulo de  de ese tamaño con tu caracter.</p>
            <br>
            <form action="ejercicio1.php" method="post">
                <div id="a" style="margin-top: 0.5%;">
                

            </div>
            <div id="b" >
               ancho<input type="number" name="ancho"><br>
               alto<input type="number" name="alto"><br>
               caracter<input type="text" name="caracter" id="caracter"><label style=" font-size: 90%;">&nbsp&nbsp escribe un <b style="font-size: 120%;">*</b> </label>

            </div><br>
            <input type="submit" value="Dibujar" name="dibujar" class="boton">
            <input type="reset" value="Borrar" name="borrar" class="boton">
            </form>
        </fieldset>
    </body>

    </html>
<?php
}
?>

